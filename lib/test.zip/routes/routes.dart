import 'package:flutter/material.dart';

class Routes {
  static const splash = '/';
  static const intro = '/intro';
  static const createAccount = '/createAccount';
  static const home = '/home';

  static Route routes(RouteSettings routeSettings) {
    print('Route name: ${routeSettings.name}');

    switch (routeSettings.name) {
      case splash:
        //return _buildRoute(SplashScreen.create);
      case intro:
        //return _buildRoute(IntroScreen.create);
      case home:
        //return _buildRoute(HomeScreen.create);
      case createAccount:
       // return _buildRoute(EmailCreate.create);
      default:
        throw Exception('Route does not exists');
    }
  }

  static MaterialPageRoute _buildRoute(Function build) => MaterialPageRoute(builder: (context) => build(context));
}
